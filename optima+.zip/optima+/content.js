function countTestsAndAssignments() {
  const testElements = document.querySelectorAll('.progressBarCell');
  let countTests = 0;
  let countLessons = 0;

  testElements.forEach((element) => {
    const backgroundColor = element.style.backgroundColor;
    const onclick = element.getAttribute('onclick');

    if (
      backgroundColor === 'rgb(251, 175, 29)' &&
      onclick && (onclick.includes('mod/quiz/view.php') || onclick.includes('mod/assign/view.php'))
    ) {
      countTests++;
    }

    if (
      backgroundColor === 'rgb(251, 175, 29)' &&
      onclick && onclick.includes('mod/lesson/view.php')
    ) {
      countLessons++;
    }
  });

  const resultContainer = document.createElement('div');
  resultContainer.style.position = 'fixed';
  resultContainer.style.top = '100px';  
  resultContainer.style.right = '10px';
  resultContainer.style.padding = '15px'; 
  resultContainer.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';  // Непрозрачность 0.8
  resultContainer.style.color = 'white';
  resultContainer.style.fontSize = '14px'; 
  resultContainer.style.borderRadius = '8px'; 
  resultContainer.style.zIndex = '1000';
  resultContainer.style.fontFamily = 'Arial, sans-serif'; 
  resultContainer.style.transition = 'all 0.3s ease';
  resultContainer.style.border = '4px solid #fff';  // Белая обводка
  resultContainer.style.boxShadow = '0 0 10px rgba(255, 255, 255, 0.6)';  // Тень

  // Контейнер для крестика
  const closeButton = document.createElement('button');
  closeButton.textContent = '×'; 
  closeButton.style.position = 'absolute';
  closeButton.style.top = '5px';
  closeButton.style.right = '5px';
  closeButton.style.backgroundColor = 'transparent';
  closeButton.style.border = 'none';
  closeButton.style.color = 'white';
  closeButton.style.fontSize = '20px';
  closeButton.style.cursor = 'pointer';
  closeButton.style.transition = 'transform 0.3s ease'; 
  resultContainer.appendChild(closeButton);

  let isCollapsed = false;

  closeButton.addEventListener('click', () => {
    if (isCollapsed) {
      resultContainer.style.height = 'auto'; 
      resultContainer.style.padding = '15px'; 
      resultContainer.style.overflow = 'visible';
      closeButton.textContent = '×';
      isCollapsed = false;
    } else {
      resultContainer.style.height = '50px'; 
      resultContainer.style.padding = '5px'; 
      resultContainer.style.overflow = 'hidden'; 
      closeButton.textContent = '-'; 
      isCollapsed = true;
    }
  });

  // Контейнер для текста "OPTIMA+"
  const titleDiv = document.createElement('div');
  titleDiv.textContent = 'OPTIMA+';
  titleDiv.style.fontSize = '16px'; 
  titleDiv.style.fontWeight = 'bold';
  titleDiv.style.color = 'white';
  titleDiv.style.textAlign = 'center';
  titleDiv.style.textShadow = '2px 2px 4px rgba(0, 0, 0, 0.7)';
  titleDiv.style.marginBottom = '10px';  // Добавляем отступ снизу
  resultContainer.appendChild(titleDiv);

  // Контейнер для вкладок
  const tabsContainer = document.createElement('div');
  tabsContainer.style.marginTop = '10px';  // Отступ сверху
  resultContainer.appendChild(tabsContainer);

  const tabMain = document.createElement('button');
  tabMain.textContent = '1';  // Просто цифра 1
  tabMain.style.padding = '5px 10px';
  tabMain.style.backgroundColor = 'transparent';
  tabMain.style.border = '1px solid #fff';
  tabMain.style.color = 'white';
  tabMain.style.cursor = 'pointer';
  tabMain.style.marginRight = '10px';
  tabMain.style.borderRadius = '5px';
  tabMain.addEventListener('click', () => showTab('main'));
  tabsContainer.appendChild(tabMain);

  const tabPage1 = document.createElement('button');
  tabPage1.textContent = '2';  // Просто цифра 2
  tabPage1.style.padding = '5px 10px';
  tabPage1.style.backgroundColor = 'transparent';
  tabPage1.style.border = '1px solid #fff';
  tabPage1.style.color = 'white';
  tabPage1.style.cursor = 'pointer';
  tabPage1.style.marginRight = '10px';
  tabPage1.style.borderRadius = '5px';
  tabPage1.addEventListener('click', () => showTab('page1'));
  tabsContainer.appendChild(tabPage1);

  const tabPage2 = document.createElement('button');
  tabPage2.textContent = '3';  // Просто цифра 3
  tabPage2.style.padding = '5px 10px';
  tabPage2.style.backgroundColor = 'transparent';
  tabPage2.style.border = '1px solid #fff';
  tabPage2.style.color = 'white';
  tabPage2.style.cursor = 'pointer';
  tabPage2.style.borderRadius = '5px';
  tabPage2.addEventListener('click', () => showTab('page2'));
  tabsContainer.appendChild(tabPage2);

  // Контейнер для контента
  const contentContainer = document.createElement('div');
  contentContainer.id = 'content-container';  // Для переключения контента
  resultContainer.appendChild(contentContainer);

  // Функция для отображения контента в зависимости от вкладки
  function showTab(tab) {
    contentContainer.innerHTML = '';  // Очищаем контент

    if (tab === 'main') {
      const mainContent = document.createElement('div');
      mainContent.innerHTML = `
        <div>Осталось тестов: ${countTests}</div>
        <div>Непрочитанных лекций: ${countLessons}</div>
        <div>Всего вместе: ${countTests + countLessons}</div>
        <div>1.1</div>
      `;

      // Ссылка "by F.I"
      const link = document.createElement('a');
      link.href = 'https://fading-ind.itch.io/';
      link.textContent = 'by F.I';
      link.style.color = 'blue';
      link.style.textDecoration = 'underline';
      link.style.fontSize = '14px';
      mainContent.appendChild(link);

      contentContainer.appendChild(mainContent);
    } else if (tab === 'page1') {
      const page1Content = document.createElement('div');
      page1Content.innerHTML = `
        <div>Coming soon....</div>
      `;
      contentContainer.appendChild(page1Content);
    } else if (tab === 'page2') {
      const page2Content = document.createElement('div');

      // Ввод даты дедлайна
      const inputDeadline = document.createElement('input');
      inputDeadline.type = 'text';
      inputDeadline.placeholder = 'Введите конец дедлайна: ДЕНЬ/МЕСЯЦ/ГОД';
      inputDeadline.style.padding = '5px';
      inputDeadline.style.marginBottom = '10px';
      inputDeadline.style.width = '100%';
      page2Content.appendChild(inputDeadline);

      // Элемент для вывода оставшегося времени
      const deadlineOutput = document.createElement('div');
      deadlineOutput.style.marginTop = '10px';
      page2Content.appendChild(deadlineOutput);

      // Проверяем наличие сохраненной даты и отображаем ее, если есть
      const savedDeadline = localStorage.getItem('deadline');
      if (savedDeadline) {
        inputDeadline.value = savedDeadline;
        const deadlineDate = parseDate(savedDeadline);
        if (deadlineDate) {
          const timeRemaining = getTimeRemaining(deadlineDate);
          deadlineOutput.innerHTML = `До конца дедлайна: ${timeRemaining.days} дней ${timeRemaining.hours} часов ${timeRemaining.minutes} минут`;
        }
      }

      inputDeadline.addEventListener('input', () => {
        const deadlineString = inputDeadline.value;

        // Ограничиваем формат даты
        const regex = /^\d{2}\/\d{2}\/\d{4}$/;
        if (regex.test(deadlineString)) {
          localStorage.setItem('deadline', deadlineString);  // Сохраняем дату
          const deadlineDate = parseDate(deadlineString);
          if (deadlineDate) {
            const timeRemaining = getTimeRemaining(deadlineDate);
            deadlineOutput.innerHTML = `До конца дедлайна: ${timeRemaining.days} дней ${timeRemaining.hours} часов ${timeRemaining.minutes} минут`;
          }
        } else {
          deadlineOutput.innerHTML = 'Неверный формат даты. Пожалуйста, используйте ДЕНЬ/МЕСЯЦ/ГОД.';
        }
      });

      contentContainer.appendChild(page2Content);
    }
  }

  // Функция для парсинга даты в формат "ДЕНЬ/МЕСЯЦ/ГОД"
  function parseDate(dateString) {
    const regex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
    const match = dateString.match(regex);
    if (match) {
      const day = parseInt(match[1], 10);
      const month = parseInt(match[2], 10) - 1;  // Месяцы начинаются с 0
      const year = parseInt(match[3], 10);
      return new Date(year, month, day);
    }
    return null;
  }

  // Функция для получения оставшегося времени
  function getTimeRemaining(deadlineDate) {
    const now = new Date();
    const diff = deadlineDate - now;

    if (diff <= 0) return { days: 0, hours: 0, minutes: 0 };

    const minutes = Math.floor(diff / 1000 / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    return {
      days: days,
      hours: hours % 24,
      minutes: minutes % 60,
    };
  }

  // Инициализация: показываем вкладку "Главная" по умолчанию
  showTab('main');

  document.body.appendChild(resultContainer);
}

// Функция для проверки обновлений
function checkForUpdate() {
fetch('https://raw.githubusercontent.com/Madnesse01/optimaplus/refs/heads/main/update.json?t=' + new Date().getTime())
    .then(response => response.json())
    .then(data => {
      const currentVersion = '1.1'; // Текущая версия
      const latestVersion = data.latest_version;
      const downloadUrl = 'https://madnesse01.github.io/optimaplus/'; // Ссылка на сайт

      console.log('Current Version:', currentVersion);
      console.log('Latest Version:', latestVersion);

      // Проверяем, совпадает ли версия
      if (currentVersion !== latestVersion) {
        // Проверка, что сообщение об обновлении еще не выведено
        const existingUpdateMessage = document.getElementById('update-message');
        if (!existingUpdateMessage) {
          const updateText = document.createElement('div');
          updateText.id = 'update-message';  // Уникальный id для проверки
          updateText.style.color = 'red';
          updateText.style.fontSize = '14px';
          updateText.textContent = `Доступно обновление! `;
          
          const link = document.createElement('a');
          link.href = downloadUrl;
          link.textContent = 'Click';
          link.style.color = 'blue';
          link.style.fontSize = '14px';
          link.style.textDecoration = 'underline';
          updateText.appendChild(link);

          // Добавляем текст обновления в блок
          const resultContainer = document.querySelector('div[style*="position: fixed"]');
          if (resultContainer) {
            resultContainer.appendChild(updateText);
          }
        }
      }
    })
    .catch(error => console.error('Ошибка при проверке обновлений:', error));
}

// Запускаем функцию каждые 10 секунд
setInterval(checkForUpdate, 10000);

countTestsAndAssignments();  // Ваш основной код
